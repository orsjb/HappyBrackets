# list your startup classes, one on each line. Do not add an extension. 
# Use dots between package names
# Eg, examples.HelloWorld 
#
# The first filename looked for will be hostname-startup.txt
$ Eg, if device is called hb-b827eb09ecf1 the file searched for will be 
# hb-b827eb09ecf1-startup.txt

# if that file does not exist, the device will look for classnames in file startup.txt