import time
for x in range(1, 10):
    time.sleep(1)
    print "We have elapsed %d seconds" % (x)

print("Script Complete")
