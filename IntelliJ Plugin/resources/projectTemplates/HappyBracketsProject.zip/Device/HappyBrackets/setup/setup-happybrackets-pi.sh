# Script to setup new pi disc image with HappyBrackets and appropriate details

# run from pi, with an internet connection
#download image from Github

curl https://raw.githubusercontent.com/orsjb/HappyBrackets/master/DeviceSetup/setup-pi-image.sh | bash
