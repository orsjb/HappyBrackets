#!/bin/sh

cd ../../

./update-package.sh
