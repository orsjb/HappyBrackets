#list your startup classes, one on each line. Do not add an extension. 
# Use dots between package names
# Eg, examples.HelloWorld 
# save the file as startup.txt